﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        string[,] Seats = new string[5, 3];
        string[] wait = new string[10];
        public Form1()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button17_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("PLEASE ENTER YOUR NAME");
            }
            if (listBox1.SelectedIndex == 0 && listBox2.SelectedIndex == 0)
            {
                Seats[0, 0] = textBox1.Text;
            }

            if (listBox1.SelectedIndex == 0 && listBox2.SelectedIndex == 1)
            {
                Seats[0, 1] = textBox1.Text;
            }

            if (listBox1.SelectedIndex == 0 && listBox2.SelectedIndex == 2)
            {
                Seats[0, 2] = textBox1.Text;
            }

            if (listBox1.SelectedIndex == 1 && listBox2.SelectedIndex == 0)
            {
                Seats[1, 0] = textBox1.Text;
            }

            if (listBox1.SelectedIndex == 1 && listBox2.SelectedIndex == 1)
            {
                Seats[1, 1] = textBox1.Text;
            }

            if (listBox1.SelectedIndex == 1 && listBox2.SelectedIndex == 2)
            {
                Seats[1, 2] = textBox1.Text;
            }

            if (listBox1.SelectedIndex == 2 && listBox2.SelectedIndex == 0)
            {
                Seats[2, 0] = textBox1.Text;
            }

            if (listBox1.SelectedIndex == 2 && listBox2.SelectedIndex == 1)
            {
                Seats[2, 1] = textBox1.Text;

            }

            if (listBox1.SelectedIndex == 2 && listBox2.SelectedIndex == 2)
            {
                Seats[2, 2] = textBox1.Text;

            }

            if (listBox1.SelectedIndex == 3 && listBox2.SelectedIndex == 0)
            {
                Seats[3, 0] = textBox1.Text;
            }

            if (listBox1.SelectedIndex == 3 && listBox2.SelectedIndex == 1)
            {
                Seats[3, 1] = textBox1.Text;
            }

            if (listBox1.SelectedIndex == 3 && listBox2.SelectedIndex == 2)
            {
                Seats[3, 2] = textBox1.Text;
            }

            if (listBox1.SelectedIndex == 4 && listBox2.SelectedIndex == 0)
            {
                Seats[4, 0] = textBox1.Text;
            }

            if (listBox1.SelectedIndex == 4 && listBox2.SelectedIndex == 1)
            {
                Seats[4, 1] = textBox1.Text;
            }

            if (listBox1.SelectedIndex == 4 && listBox2.SelectedIndex == 2)
            {
                Seats[4, 2] = textBox1.Text;
            }


        }

        private void button20_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = "";
            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    richTextBox1.Text += Seats[i, j] + "\n";
                }
            }
        }

        private void button22_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Seats[i, j] = "Harman ";
                }
            }
        }

        private void button18_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex == 0 && listBox2.SelectedIndex == 0)
            {
                Seats[0, 0] = "";
            }

            if (listBox1.SelectedIndex == 0 && listBox2.SelectedIndex == 1)
            {
                Seats[0, 1] = "";
            }

            if (listBox1.SelectedIndex == 0 && listBox2.SelectedIndex == 2)
            {
                Seats[0, 2] = "";
            }

            if (listBox1.SelectedIndex == 1 && listBox2.SelectedIndex == 0)
            {
                Seats[1, 0] = "";
            }

            if (listBox1.SelectedIndex == 1 && listBox2.SelectedIndex == 1)
            {
                Seats[1, 1] = "";
            }

            if (listBox1.SelectedIndex == 1 && listBox2.SelectedIndex == 2)
            {
                Seats[1, 2] = "";
            }

            if (listBox1.SelectedIndex == 2 && listBox2.SelectedIndex == 0)
            {
                Seats[2, 0] = "";
            }

            if (listBox1.SelectedIndex == 2 && listBox2.SelectedIndex == 1)
            {
                Seats[2, 1] = "";

            }

            if (listBox1.SelectedIndex == 2 && listBox2.SelectedIndex == 2)
            {
                Seats[2, 2] = "";

            }

            if (listBox1.SelectedIndex == 3 && listBox2.SelectedIndex == 0)
            {
                Seats[3, 0] = "";
            }

            if (listBox1.SelectedIndex == 3 && listBox2.SelectedIndex == 1)
            {
                Seats[3, 1] = "";
            }

            if (listBox1.SelectedIndex == 3 && listBox2.SelectedIndex == 2)
            {
                Seats[3, 2] = "";
            }

            if (listBox1.SelectedIndex == 4 && listBox2.SelectedIndex == 0)
            {
                Seats[4, 0] = "";
            }

            if (listBox1.SelectedIndex == 4 && listBox2.SelectedIndex == 1)
            {
                Seats[4, 1] = "";
            }

            if (listBox1.SelectedIndex == 4 && listBox2.SelectedIndex == 2)
            {
                Seats[4, 2] = "";
            }
        }

        private void button19_Click(object sender, EventArgs e)
        {
            try
            {
                for (int i = 0; i < 5; i++)
                {
                    for (int j = 0; j < 3; j++)
                        if (Seats[i, j] == "")
                        {
                         
                        }
                        else
                        {
                            if (wait[0] == "")
                            {
                                wait[0] = textBox1.Text;
                            }
                            else if (x[1] == "")
                            {
                                wait[1] = textBox1.Text;
                            }
                            else if (wait[2] == "")
                            {
                                wait[2] = textBox1.Text;
                            }
                            else if (wait[3] == "")
                            {
                                wait[3] = textBox1.Text;
                            }
                            else if (wait[4] == "")
                            {
                                wait[4] = textBox1.Text;
                            }
                            else if (wait[5] == "")
                            {
                                wait[5] = textBox1.Text;
                            }
                            else if (wait[6] == "")
                            {
                                wait[6] = textBox1.Text;
                            }
                            else if (x[7] == "")
                            {
                                wait[7] = textBox1.Text;
                            }
                            else if (wait[8] == "")
                            {
                                wait[8] = textBox1.Text;
                            }
                            else if (wait[9] == "")
                            {
                                wait[9] = textBox1.Text;
                            }
                        }


                }
            }
            catch (Exception)
            { }
        }
    }
}

